# GearPocket 🎧⚡

แหล่งรวมรีวิวอุปกรณ์เสริมมือถือที่ครบที่สุด — Next.js 14 + TypeScript + Tailwind CSS

## Features

- ✅ **Next.js 14 App Router** — Server Components, Static Generation
- ✅ **Full SEO** — Metadata API, Open Graph, Sitemap, Robots.txt
- ✅ **Responsive Design** — Mobile-first ทุกหน้า
- ✅ **Dark Theme** — ดีไซน์ Navy + Electric Blue/Indigo
- ✅ **Performance** — Image optimization, font preloading
- ✅ **Ready for Vercel** — Zero-config deploy

## Tech Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS |
| Icons | Lucide React |
| Fonts | Space Grotesk + Inter + JetBrains Mono |
| Deploy | Vercel |

## Project Structure

```
src/
├── app/
│   ├── layout.tsx          # Root layout + SEO metadata
│   ├── page.tsx            # Homepage
│   ├── not-found.tsx       # 404 page
│   ├── sitemap.ts          # XML sitemap
│   ├── robots.ts           # robots.txt
│   ├── reviews/
│   │   ├── page.tsx        # All reviews listing
│   │   └── [slug]/page.tsx # Review detail page
│   ├── categories/
│   │   └── page.tsx        # Category listing
│   └── about/
│       └── page.tsx        # About page
├── components/
│   ├── layout/
│   │   ├── Navbar.tsx
│   │   └── Footer.tsx
│   └── ui/
│       ├── ReviewCard.tsx
│       ├── StarRating.tsx
│       ├── Badge.tsx
│       └── CategoryFilter.tsx
├── data/
│   └── reviews.ts          # Mock review data
└── types/
    └── index.ts            # TypeScript types
```

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deploy to Vercel

### Option 1: Vercel CLI
```bash
npm i -g vercel
vercel
```

### Option 2: GitHub Integration
1. Push โปรเจกต์ขึ้น GitHub
2. ไปที่ [vercel.com](https://vercel.com) → Import Project
3. เลือก repo → Deploy
4. Vercel จะ detect Next.js อัตโนมัติ

### Environment Variables
ไม่มี env vars ที่จำเป็นสำหรับ static version นี้

## Adding Real Content

แทนที่ข้อมูลใน `src/data/reviews.ts` ด้วยข้อมูลจริง หรือเชื่อมต่อกับ:
- **Contentful / Sanity** — Headless CMS
- **Supabase / PlanetScale** — Database
- **MDX** — Markdown-based reviews

## Customization

- **สี**: แก้ใน `tailwind.config.js` → `theme.extend.colors`
- **ฟอนต์**: แก้ใน `src/app/globals.css` → `@import url(...)`
- **SEO**: แก้ใน `src/app/layout.tsx` → `metadata`
- **โดเมน**: แก้ `metadataBase` ใน layout.tsx และ sitemap.ts

---

Built with ❤️ by GearPocket Team
