import type { Metadata } from 'next';
import './globals.css';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';

export const metadata: Metadata = {
  title: {
    default: 'GearPocket — รีวิวอุปกรณ์เสริมมือถือ',
    template: '%s | GearPocket',
  },
  description:
    'รีวิวอุปกรณ์เสริมมือถือที่ดีที่สุด ครอบคลุมหูฟัง Power Bank พัดลมพกพา ลำโพง และอื่นๆ อีกมากมาย พร้อมสเปคและราคา',
  keywords: ['รีวิวหูฟัง', 'Power Bank', 'พัดลมพกพา', 'อุปกรณ์เสริมมือถือ', 'รีวิวมือถือ'],
  authors: [{ name: 'GearPocket Team' }],
  creator: 'GearPocket',
  metadataBase: new URL('https://gearpocket.vercel.app'),
  openGraph: {
    type: 'website',
    locale: 'th_TH',
    url: 'https://gearpocket.vercel.app',
    siteName: 'GearPocket',
    title: 'GearPocket — รีวิวอุปกรณ์เสริมมือถือ',
    description: 'รีวิวอุปกรณ์เสริมมือถือที่ดีที่สุด ครบ จริง ตรงไปตรงมา',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'GearPocket',
    description: 'รีวิวอุปกรณ์เสริมมือถือที่ดีที่สุด',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true },
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="th" className="scroll-smooth">
      <body className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
