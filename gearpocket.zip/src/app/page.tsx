import Link from 'next/link';
import { ArrowRight, Zap, Shield, Star } from 'lucide-react';
import { getFeaturedReviews, getLatestReviews } from '@/data/reviews';
import ReviewCard from '@/components/ui/ReviewCard';
import CategoryFilter from '@/components/ui/CategoryFilter';

export default function HomePage() {
  const featured = getFeaturedReviews();
  const latest = getLatestReviews();

  return (
    <>
      {/* ─── HERO ─── */}
      <section className="relative min-h-[88vh] flex items-center pt-16 overflow-hidden">
        {/* Radial glow bg */}
        <div className="absolute inset-0 bg-gradient-hero pointer-events-none" />

        {/* Animated orbs */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-accent-blue/10 blur-3xl animate-pulse-slow pointer-events-none" />
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 rounded-full bg-accent-indigo/10 blur-3xl animate-pulse-slow pointer-events-none" style={{ animationDelay: '2s' }} />

        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-20">
          <div className="max-w-3xl">
            {/* Eyebrow */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-accent-indigo/10 border border-accent-indigo/30 mb-6">
              <Zap size={12} className="text-accent-glow" />
              <span className="text-xs font-display font-semibold text-accent-glow tracking-wide">
                รีวิวจริง · ทดสอบจริง · ไม่มีสปอนเซอร์ซ่อน
              </span>
            </div>

            <h1 className="font-display font-bold text-5xl sm:text-6xl lg:text-7xl text-white leading-[1.05] tracking-tight mb-6">
              อุปกรณ์ที่ใช่
              <br />
              <span className="text-gradient">ในกระเป๋าคุณ</span>
            </h1>

            <p className="text-lg sm:text-xl text-slate-400 leading-relaxed mb-10 max-w-xl">
              รีวิวหูฟัง, Power Bank, พัดลมพกพา และอุปกรณ์เสริมมือถือทุกชนิด
              พร้อมสเปค ข้อดีข้อเสีย และราคาจริงจากการใช้งานจริง
            </p>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <Link href="/reviews" className="btn-primary">
                ดูรีวิวทั้งหมด
                <ArrowRight size={16} />
              </Link>
              <Link href="#featured" className="btn-ghost">
                รีวิวยอดนิยม
              </Link>
            </div>
          </div>

          {/* Stats row */}
          <div className="mt-16 grid grid-cols-3 gap-4 sm:gap-8 max-w-lg">
            {[
              { value: '120+', label: 'รีวิวสินค้า' },
              { value: '4.8★', label: 'คะแนนเฉลี่ย' },
              { value: '50K+', label: 'ผู้อ่านต่อเดือน' },
            ].map((s) => (
              <div key={s.label}>
                <p className="font-display font-bold text-2xl sm:text-3xl text-white">{s.value}</p>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── WHY TRUST US ─── */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { icon: Shield, title: 'ซื้อมาทดสอบเอง', desc: 'ทุกชิ้นที่รีวิวซื้อมาจากร้านค้าจริง ไม่ใช่สินค้ารับมาจากบริษัท' },
            { icon: Star, title: 'คะแนนโปร่งใส', desc: 'ระบบให้คะแนน 10 เกณฑ์ แยกย่อยทุกด้านอย่างละเอียด' },
            { icon: Zap, title: 'อัปเดตสม่ำเสมอ', desc: 'รีวิวใหม่ทุกสัปดาห์ ตามทันทุกสินค้าที่เปิดตัวในตลาด' },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="flex items-start gap-4 p-5 rounded-2xl bg-navy-800 border border-navy-700">
              <div className="w-9 h-9 rounded-lg bg-accent-indigo/10 border border-accent-indigo/20 flex items-center justify-center shrink-0">
                <Icon size={16} className="text-accent-glow" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-sm text-white mb-1">{title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ─── FEATURED REVIEWS ─── */}
      <section id="featured" className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-xs font-display font-semibold text-accent-blue uppercase tracking-widest mb-2">
              รีวิวแนะนำ
            </p>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-white">
              เลือกมาแล้วว่าดีที่สุด
            </h2>
          </div>
          <Link href="/reviews" className="btn-ghost hidden sm:flex">
            ดูทั้งหมด <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {featured.map((r) => (
            <ReviewCard key={r.id} review={r} featured />
          ))}
        </div>

        <div className="mt-6 sm:hidden">
          <Link href="/reviews" className="btn-ghost w-full justify-center">
            ดูรีวิวทั้งหมด <ArrowRight size={14} />
          </Link>
        </div>
      </section>

      {/* ─── LATEST REVIEWS ─── */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-24">
        <div className="flex items-end justify-between mb-6">
          <div>
            <p className="text-xs font-display font-semibold text-accent-blue uppercase tracking-widest mb-2">
              ล่าสุด
            </p>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-white">
              รีวิวใหม่ล่าสุด
            </h2>
          </div>
        </div>

        <div className="mb-6">
          <CategoryFilter />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {latest.map((r) => (
            <ReviewCard key={r.id} review={r} />
          ))}
        </div>
      </section>

      {/* ─── CTA BANNER ─── */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-24">
        <div className="relative rounded-3xl overflow-hidden p-8 sm:p-12 text-center"
          style={{ background: 'linear-gradient(135deg, rgba(59,130,246,0.15), rgba(99,102,241,0.2))', border: '1px solid rgba(99,102,241,0.3)' }}>
          <div className="absolute inset-0 bg-gradient-hero pointer-events-none" />
          <div className="relative">
            <h2 className="font-display font-bold text-3xl sm:text-4xl text-white mb-4">
              ไม่พลาดรีวิวใหม่
            </h2>
            <p className="text-slate-400 mb-8 max-w-md mx-auto">
              ติดตาม GearPocket เพื่อรับรีวิวสินค้าล่าสุด เปรียบเทียบราคา และดีลสุดคุ้มทุกสัปดาห์
            </p>
            <div className="flex flex-col sm:flex-row gap-3 max-w-sm mx-auto">
              <input
                type="email"
                placeholder="อีเมลของคุณ"
                className="flex-1 px-4 py-3 rounded-xl bg-navy-900/80 border border-navy-700 text-white placeholder-slate-500 text-sm font-body focus:outline-none focus:border-accent-indigo transition-colors"
              />
              <button className="btn-primary justify-center whitespace-nowrap">
                ติดตามเลย
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
