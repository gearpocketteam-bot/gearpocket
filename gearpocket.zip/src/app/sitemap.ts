import { MetadataRoute } from 'next';
import { getLatestReviews } from '@/data/reviews';

export default function sitemap(): MetadataRoute.Sitemap {
  const reviews = getLatestReviews();
  const base = 'https://gearpocket.vercel.app';

  const reviewUrls = reviews.map((r) => ({
    url: `${base}/reviews/${r.slug}`,
    lastModified: new Date(r.publishedAt),
    changeFrequency: 'monthly' as const,
    priority: 0.8,
  }));

  return [
    { url: base, lastModified: new Date(), changeFrequency: 'daily', priority: 1 },
    { url: `${base}/reviews`, lastModified: new Date(), changeFrequency: 'daily', priority: 0.9 },
    { url: `${base}/categories`, lastModified: new Date(), changeFrequency: 'weekly', priority: 0.7 },
    { url: `${base}/about`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.5 },
    ...reviewUrls,
  ];
}
