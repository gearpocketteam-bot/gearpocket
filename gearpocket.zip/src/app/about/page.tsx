import type { Metadata } from 'next';
import { Zap, Shield, Star, Users } from 'lucide-react';

export const metadata: Metadata = {
  title: 'เกี่ยวกับ GearPocket',
  description: 'เรื่องราวของ GearPocket แหล่งรวมรีวิวอุปกรณ์เสริมมือถือที่ซื่อสัตย์ที่สุด',
};

export default function AboutPage() {
  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-accent flex items-center justify-center mx-auto mb-6 shadow-glow-md">
            <Zap size={28} className="text-white" strokeWidth={2} />
          </div>
          <h1 className="font-display font-bold text-4xl sm:text-5xl text-white mb-4">
            เกี่ยวกับ Gear<span className="text-gradient">Pocket</span>
          </h1>
          <p className="text-lg text-slate-400 leading-relaxed">
            เราเชื่อว่าทุกคนสมควรได้ข้อมูลที่ซื่อสัตย์ก่อนตัดสินใจซื้อ
          </p>
        </div>

        {/* Story */}
        <div className="prose prose-invert prose-slate max-w-none mb-12 space-y-4">
          <p className="text-slate-300 leading-relaxed">
            GearPocket เริ่มต้นจากความหงุดสะดุ้งของนักรีวิวสมัครเล่นที่ซื้อหูฟังมาหนึ่งชุด แล้วพบว่ารีวิวที่เห็นในอินเทอร์เน็ตนั้นถูกสปอนเซอร์ทั้งหมด
            เราจึงตัดสินใจสร้างพื้นที่ที่โปร่งใสและตรงไปตรงมา
          </p>
          <p className="text-slate-300 leading-relaxed">
            ทุกสินค้าที่เรารีวิวซื้อมาเองด้วยเงินส่วนตัว ทดสอบในสภาพแวดล้อมจริง และให้คะแนนตามเกณฑ์มาตรฐานที่เราตั้งขึ้น
            ไม่มีการรับเงินจากแบรนด์เพื่อเปลี่ยนคะแนน
          </p>
        </div>

        {/* Values */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-12">
          {[
            { icon: Shield, title: 'ความซื่อสัตย์', desc: 'ไม่รับสินค้ารีวิวฟรีหรือเงินสนับสนุนจากแบรนด์ที่อาจทำให้เกิดความลำเอียง' },
            { icon: Star, title: 'มาตรฐานสูง', desc: 'ทดสอบอย่างน้อย 2 สัปดาห์ก่อนเขียนรีวิว เพื่อครอบคลุมการใช้งานหลากหลายสถานการณ์' },
            { icon: Zap, title: 'ทันสมัยเสมอ', desc: 'อัปเดตรีวิวเก่าเมื่อพบข้อมูลใหม่ ราคาเปลี่ยน หรือ Firmware update เปลี่ยนประสิทธิภาพ' },
            { icon: Users, title: 'ชุมชน', desc: 'เปิดรับคำแนะนำและคำวิจารณ์จากผู้อ่านเสมอ เพราะประสบการณ์จริงสำคัญที่สุด' },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="p-5 rounded-2xl bg-navy-800 border border-navy-700">
              <div className="w-9 h-9 rounded-lg bg-accent-indigo/10 border border-accent-indigo/20 flex items-center justify-center mb-4">
                <Icon size={16} className="text-accent-glow" />
              </div>
              <h3 className="font-display font-bold text-white mb-2">{title}</h3>
              <p className="text-sm text-slate-400 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        {/* Contact */}
        <div className="p-6 rounded-2xl bg-gradient-card border border-accent-indigo/20 text-center">
          <h3 className="font-display font-bold text-white mb-2">ติดต่อเรา</h3>
          <p className="text-slate-400 text-sm mb-4">มีสินค้าแนะนำ หรืออยากร่วมงานกัน?</p>
          <a href="mailto:hello@gearpocket.co" className="btn-primary inline-flex">
            hello@gearpocket.co
          </a>
        </div>
      </div>
    </div>
  );
}
