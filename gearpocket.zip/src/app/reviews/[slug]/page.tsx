import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowLeft, Clock, CheckCircle2, XCircle, ChevronRight } from 'lucide-react';
import { getReviewBySlug, getLatestReviews } from '@/data/reviews';
import StarRating from '@/components/ui/StarRating';
import Badge from '@/components/ui/Badge';
import ReviewCard from '@/components/ui/ReviewCard';

interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const review = getReviewBySlug(params.slug);
  if (!review) return { title: 'ไม่พบรีวิว' };
  return {
    title: `รีวิว ${review.title}`,
    description: review.excerpt,
    openGraph: {
      title: `รีวิว ${review.title} | GearPocket`,
      description: review.excerpt,
      images: [review.coverImage],
    },
  };
}

export async function generateStaticParams() {
  const reviews = getLatestReviews();
  return reviews.map((r) => ({ slug: r.slug }));
}

export default function ReviewDetailPage({ params }: Props) {
  const review = getReviewBySlug(params.slug);
  if (!review) notFound();

  const related = getLatestReviews()
    .filter((r) => r.id !== review.id && r.category === review.category)
    .slice(0, 3);

  const formattedDate = new Date(review.publishedAt).toLocaleDateString('th-TH', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="min-h-screen pt-20">
      {/* Hero image */}
      <div className="relative h-64 sm:h-80 lg:h-96 w-full">
        <Image
          src={review.coverImage}
          alt={review.title}
          fill
          priority
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-900 via-navy-900/60 to-transparent" />

        {/* Overlay content */}
        <div className="absolute bottom-0 left-0 right-0 max-w-4xl mx-auto px-4 sm:px-6 pb-8">
          <Link
            href="/reviews"
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white mb-4 transition-colors"
          >
            <ArrowLeft size={13} />
            กลับไปรีวิวทั้งหมด
          </Link>
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <Badge badge={review.badge} />
            <span className="text-xs font-display font-semibold px-2.5 py-1 rounded-full bg-navy-900/80 text-accent-glow border border-accent-indigo/30">
              {review.category}
            </span>
          </div>
          <h1 className="font-display font-bold text-3xl sm:text-4xl text-white mb-2">
            {review.title}
          </h1>
          <div className="flex flex-wrap items-center gap-4 text-sm text-slate-400">
            <StarRating rating={review.rating} size={14} />
            <span className="flex items-center gap-1.5">
              <Clock size={13} />
              {review.readTime} นาทีอ่าน
            </span>
            <span>{formattedDate}</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Excerpt */}
            <p className="text-lg text-slate-300 leading-relaxed border-l-2 border-accent-indigo pl-4">
              {review.excerpt}
            </p>

            {/* Pros & Cons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Pros */}
              <div className="p-5 rounded-2xl bg-emerald-500/5 border border-emerald-500/20">
                <h3 className="font-display font-bold text-sm text-emerald-400 uppercase tracking-wide mb-3 flex items-center gap-2">
                  <CheckCircle2 size={15} />
                  ข้อดี
                </h3>
                <ul className="space-y-2">
                  {review.pros.map((p) => (
                    <li key={p} className="flex items-start gap-2 text-sm text-slate-300">
                      <span className="text-emerald-400 mt-0.5 shrink-0">+</span>
                      {p}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Cons */}
              <div className="p-5 rounded-2xl bg-red-500/5 border border-red-500/20">
                <h3 className="font-display font-bold text-sm text-red-400 uppercase tracking-wide mb-3 flex items-center gap-2">
                  <XCircle size={15} />
                  ข้อเสีย
                </h3>
                <ul className="space-y-2">
                  {review.cons.map((c) => (
                    <li key={c} className="flex items-start gap-2 text-sm text-slate-300">
                      <span className="text-red-400 mt-0.5 shrink-0">−</span>
                      {c}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Verdict */}
            <div className="p-6 rounded-2xl bg-gradient-card border border-accent-indigo/20 shadow-glow-sm">
              <h3 className="font-display font-bold text-sm text-accent-glow uppercase tracking-widest mb-3">
                สรุปรีวิว
              </h3>
              <p className="text-slate-200 leading-relaxed">{review.verdict}</p>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-5">
            {/* Price card */}
            <div className="p-5 rounded-2xl bg-navy-800 border border-navy-700">
              <p className="text-xs font-display text-slate-500 uppercase tracking-wide mb-1">ราคาอ้างอิง</p>
              <p className="font-display font-bold text-3xl text-white mb-1">
                ฿{review.price.toLocaleString()}
              </p>
              <p className="text-xs text-slate-500 mb-4">ณ วันที่ทดสอบ</p>
              <div className="flex items-center gap-2 mb-4">
                <StarRating rating={review.rating} size={16} />
              </div>
              <a
                href="#"
                className="btn-primary w-full justify-center text-sm"
              >
                ดูราคาปัจจุบัน
                <ChevronRight size={14} />
              </a>
            </div>

            {/* Specs */}
            <div className="p-5 rounded-2xl bg-navy-800 border border-navy-700">
              <h3 className="font-display font-bold text-sm text-white mb-4">สเปคหลัก</h3>
              <div className="space-y-3">
                {review.specs.map((s) => (
                  <div key={s.label} className="flex items-center justify-between">
                    <span className="text-xs text-slate-500 font-mono">{s.label}</span>
                    <span className="text-xs text-slate-200 font-mono font-medium">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Related reviews */}
        {related.length > 0 && (
          <div className="mt-16">
            <h2 className="font-display font-bold text-xl text-white mb-6">
              รีวิวในหมวดเดียวกัน
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {related.map((r) => (
                <ReviewCard key={r.id} review={r} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
