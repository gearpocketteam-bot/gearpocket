import type { Metadata } from 'next';
import { getLatestReviews } from '@/data/reviews';
import ReviewCard from '@/components/ui/ReviewCard';
import CategoryFilter from '@/components/ui/CategoryFilter';

export const metadata: Metadata = {
  title: 'รีวิวทั้งหมด',
  description: 'รายการรีวิวอุปกรณ์เสริมมือถือทั้งหมดของ GearPocket — หูฟัง Power Bank พัดลมพกพา และอื่นๆ',
};

export default function ReviewsPage() {
  const reviews = getLatestReviews();

  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="mb-10">
          <p className="text-xs font-display font-semibold text-accent-blue uppercase tracking-widest mb-2">
            รีวิวทั้งหมด
          </p>
          <h1 className="font-display font-bold text-3xl sm:text-4xl text-white mb-4">
            อุปกรณ์ที่ผ่านมือเราแล้ว
          </h1>
          <p className="text-slate-400 max-w-xl">
            รีวิวครบ ตรงไปตรงมา พร้อมสเปคและคะแนนจากการทดสอบจริง
          </p>
        </div>

        {/* Filter */}
        <div className="mb-8">
          <CategoryFilter />
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {reviews.map((r) => (
            <ReviewCard key={r.id} review={r} />
          ))}
        </div>

        {/* Load more (static placeholder) */}
        <div className="mt-12 text-center">
          <button className="btn-ghost">โหลดเพิ่มเติม</button>
        </div>
      </div>
    </div>
  );
}
