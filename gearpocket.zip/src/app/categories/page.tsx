import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'หมวดหมู่',
  description: 'หมวดหมู่อุปกรณ์เสริมมือถือทั้งหมดใน GearPocket',
};

const categories = [
  { name: 'หูฟัง', emoji: '🎧', desc: 'หูฟังครอบหู, In-Ear, TWS ทุกแบรนด์', count: 24, href: '/categories/หูฟัง' },
  { name: 'Power Bank', emoji: '🔋', desc: 'แบตสำรองทุกขนาด ชาร์จเร็ว ชาร์จไว', count: 18, href: '/categories/Power Bank' },
  { name: 'พัดลมพกพา', emoji: '💨', desc: 'พัดลมมือถือ พัดลมตั้งโต๊ะขนาดเล็ก', count: 12, href: '/categories/พัดลมพกพา' },
  { name: 'ลำโพง', emoji: '🔊', desc: 'ลำโพงบลูทูธพกพา กันน้ำ กันฝุ่น', count: 15, href: '/categories/ลำโพง' },
  { name: 'เคสมือถือ', emoji: '📱', desc: 'เคสกันกระแทก เคสหนัง เคสใส ทุกรุ่น', count: 30, href: '/categories/เคสมือถือ' },
  { name: 'สายชาร์จ', emoji: '⚡', desc: 'สายชาร์จ USB-C, Lightning, ชาร์จเร็ว', count: 20, href: '/categories/สายชาร์จ' },
];

export default function CategoriesPage() {
  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="mb-10">
          <p className="text-xs font-display font-semibold text-accent-blue uppercase tracking-widest mb-2">
            หมวดหมู่
          </p>
          <h1 className="font-display font-bold text-3xl sm:text-4xl text-white mb-4">
            เลือกตามประเภทสินค้า
          </h1>
          <p className="text-slate-400">ค้นหารีวิวสินค้าที่คุณต้องการได้เลย</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {categories.map((cat) => (
            <Link key={cat.name} href={cat.href} className="group">
              <div className="card-shimmer p-6 h-full transition-transform duration-200 group-hover:-translate-y-1 shadow-card group-hover:shadow-glow-sm">
                <div className="text-4xl mb-4">{cat.emoji}</div>
                <h2 className="font-display font-bold text-lg text-white mb-2 group-hover:text-gradient transition-all">
                  {cat.name}
                </h2>
                <p className="text-sm text-slate-400 mb-4 leading-relaxed">{cat.desc}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-accent-blue">{cat.count} รีวิว</span>
                  <span className="text-xs font-display font-semibold text-accent-glow group-hover:translate-x-1 transition-transform inline-block">
                    ดูทั้งหมด →
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
