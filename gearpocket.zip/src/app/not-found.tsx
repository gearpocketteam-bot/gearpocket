import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="text-center">
        <p className="font-mono text-7xl font-bold text-gradient mb-4">404</p>
        <h1 className="font-display font-bold text-2xl text-white mb-3">ไม่พบหน้าที่ต้องการ</h1>
        <p className="text-slate-400 mb-8">หน้านี้อาจถูกลบไปแล้ว หรือ URL อาจไม่ถูกต้อง</p>
        <Link href="/" className="btn-primary">
          กลับหน้าแรก
        </Link>
      </div>
    </div>
  );
}
