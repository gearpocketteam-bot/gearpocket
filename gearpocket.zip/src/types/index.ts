export type Category =
  | 'หูฟัง'
  | 'Power Bank'
  | 'พัดลมพกพา'
  | 'เคสมือถือ'
  | 'สายชาร์จ'
  | 'ลำโพง';

export interface Spec {
  label: string;
  value: string;
}

export interface Review {
  id: string;
  slug: string;
  title: string;
  brand: string;
  category: Category;
  rating: number;
  price: number;
  coverImage: string;
  excerpt: string;
  pros: string[];
  cons: string[];
  specs: Spec[];
  verdict: string;
  publishedAt: string;
  readTime: number;
  featured: boolean;
  badge?: 'Best Value' | 'Editor\'s Pick' | 'New' | 'Top Rated';
}
