'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Menu, X, Zap } from 'lucide-react';

const navLinks = [
  { href: '/', label: 'หน้าแรก' },
  { href: '/reviews', label: 'รีวิวทั้งหมด' },
  { href: '/categories', label: 'หมวดหมู่' },
  { href: '/about', label: 'เกี่ยวกับ' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-glass border-b border-navy-700/60 shadow-card' : 'bg-transparent'
      }`}
    >
      <nav className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-lg bg-gradient-accent flex items-center justify-center shadow-glow-sm group-hover:shadow-glow-md transition-shadow">
            <Zap size={16} className="text-white" strokeWidth={2.5} />
          </div>
          <span className="font-display font-bold text-xl text-white tracking-tight">
            Gear<span className="text-gradient">Pocket</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <ul className="hidden md:flex items-center gap-1">
          {navLinks.map((l) => (
            <li key={l.href}>
              <Link
                href={l.href}
                className="px-4 py-2 rounded-lg text-sm font-body font-medium text-slate-300 hover:text-white hover:bg-navy-800 transition-all duration-150"
              >
                {l.label}
              </Link>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <Link href="/reviews" className="btn-primary text-sm px-5 py-2">
            ดูรีวิวล่าสุด
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-navy-800 transition-colors"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`md:hidden bg-glass border-b border-navy-700/60 overflow-hidden transition-all duration-300 ${
          open ? 'max-h-72 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <ul className="px-4 py-3 space-y-1">
          {navLinks.map((l) => (
            <li key={l.href}>
              <Link
                href={l.href}
                onClick={() => setOpen(false)}
                className="block px-4 py-2.5 rounded-lg text-sm font-body text-slate-300 hover:text-white hover:bg-navy-800 transition-all"
              >
                {l.label}
              </Link>
            </li>
          ))}
          <li className="pt-2">
            <Link href="/reviews" className="btn-primary w-full justify-center">
              ดูรีวิวล่าสุด
            </Link>
          </li>
        </ul>
      </div>
    </header>
  );
}
