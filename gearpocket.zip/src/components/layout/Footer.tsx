import Link from 'next/link';
import { Zap, Twitter, Youtube, Facebook } from 'lucide-react';

const categories = ['หูฟัง', 'Power Bank', 'พัดลมพกพา', 'เคสมือถือ', 'ลำโพง', 'สายชาร์จ'];

export default function Footer() {
  return (
    <footer className="border-t border-navy-700/60 bg-navy-950 mt-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg bg-gradient-accent flex items-center justify-center">
                <Zap size={14} className="text-white" strokeWidth={2.5} />
              </div>
              <span className="font-display font-bold text-lg text-white">
                Gear<span className="text-gradient">Pocket</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-xs">
              แหล่งรวมรีวิวอุปกรณ์เสริมมือถือที่ครบที่สุด ตรงไปตรงมา ไม่มีโฆษณาซ่อน
            </p>
            <div className="flex items-center gap-3 mt-5">
              {[Twitter, Youtube, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-8 h-8 rounded-lg bg-navy-800 border border-navy-700 flex items-center justify-center text-slate-400 hover:text-white hover:border-accent-indigo transition-all"
                >
                  <Icon size={14} />
                </a>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-display font-semibold text-sm text-white mb-4 uppercase tracking-wider">
              หมวดหมู่
            </h3>
            <ul className="space-y-2">
              {categories.map((c) => (
                <li key={c}>
                  <Link
                    href={`/categories/${encodeURIComponent(c)}`}
                    className="text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    {c}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Links */}
          <div>
            <h3 className="font-display font-semibold text-sm text-white mb-4 uppercase tracking-wider">
              เพิ่มเติม
            </h3>
            <ul className="space-y-2">
              {['เกี่ยวกับเรา', 'นโยบายความเป็นส่วนตัว', 'ติดต่อเรา', 'แจ้งข้อผิดพลาด'].map((l) => (
                <li key={l}>
                  <a href="#" className="text-sm text-slate-400 hover:text-white transition-colors">
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="pt-6 border-t border-navy-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-slate-500">© 2025 GearPocket. สงวนลิขสิทธิ์ทุกประการ</p>
          <p className="text-xs text-slate-600">
            สร้างด้วย Next.js · TypeScript · Tailwind CSS
          </p>
        </div>
      </div>
    </footer>
  );
}
