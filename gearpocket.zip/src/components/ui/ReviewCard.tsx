import Link from 'next/link';
import Image from 'next/image';
import { Clock, ChevronRight } from 'lucide-react';
import { Review } from '@/types';
import StarRating from './StarRating';
import Badge from './Badge';

interface ReviewCardProps {
  review: Review;
  featured?: boolean;
}

export default function ReviewCard({ review, featured = false }: ReviewCardProps) {
  return (
    <Link href={`/reviews/${review.slug}`} className="group block">
      <article
        className={`card-shimmer h-full flex flex-col transition-transform duration-300 group-hover:-translate-y-1 shadow-card group-hover:shadow-glow-sm ${
          featured ? '' : ''
        }`}
      >
        {/* Cover image */}
        <div className={`relative overflow-hidden ${featured ? 'h-48 sm:h-56' : 'h-44'}`}>
          <Image
            src={review.coverImage}
            alt={review.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          />
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-navy-800/80 via-transparent to-transparent" />

          {/* Top badges */}
          <div className="absolute top-3 left-3 flex items-center gap-2">
            <Badge badge={review.badge} />
          </div>

          {/* Category tag */}
          <div className="absolute top-3 right-3">
            <span className="text-xs font-display font-semibold px-2.5 py-1 rounded-full bg-navy-900/80 text-accent-glow border border-accent-indigo/30 backdrop-blur-sm">
              {review.category}
            </span>
          </div>

          {/* Price bottom left */}
          <div className="absolute bottom-3 left-3">
            <span className="font-mono font-bold text-white text-sm">
              ฿{review.price.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="flex flex-col flex-1 p-4">
          <div className="flex items-center justify-between mb-2">
            <StarRating rating={review.rating} size={12} />
            <div className="flex items-center gap-1 text-slate-500 text-xs">
              <Clock size={11} />
              <span>{review.readTime} นาที</span>
            </div>
          </div>

          <p className="text-[11px] font-display font-medium text-accent-blue uppercase tracking-widest mb-1">
            {review.brand}
          </p>

          <h3 className="font-display font-bold text-white text-base leading-snug mb-2 group-hover:text-gradient transition-all">
            {review.title}
          </h3>

          <p className="text-sm text-slate-400 leading-relaxed line-clamp-2 flex-1">
            {review.excerpt}
          </p>

          <div className="mt-3 flex items-center text-xs font-display font-semibold text-accent-glow group-hover:gap-2 gap-1 transition-all">
            อ่านรีวิว
            <ChevronRight size={13} className="transition-transform group-hover:translate-x-1" />
          </div>
        </div>

        {/* Spec strip */}
        {review.specs.length > 0 && (
          <div className="spec-strip px-4 py-2.5 flex items-center gap-3 overflow-x-auto scrollbar-none">
            {review.specs.slice(0, 3).map((s) => (
              <div key={s.label} className="flex items-center gap-1.5 shrink-0">
                <span className="text-[10px] text-slate-500 uppercase tracking-wide font-mono">
                  {s.label}
                </span>
                <span className="text-[10px] text-slate-300 font-mono font-medium">{s.value}</span>
              </div>
            ))}
          </div>
        )}
      </article>
    </Link>
  );
}
