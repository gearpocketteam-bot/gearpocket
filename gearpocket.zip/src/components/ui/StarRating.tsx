import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  size?: number;
  showNumber?: boolean;
}

export default function StarRating({ rating, size = 14, showNumber = true }: StarRatingProps) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;

  return (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center gap-0.5">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            size={size}
            strokeWidth={1.5}
            className={
              i < full
                ? 'fill-rating text-rating'
                : i === full && half
                ? 'fill-rating/50 text-rating'
                : 'fill-navy-700 text-navy-600'
            }
          />
        ))}
      </div>
      {showNumber && (
        <span className="font-mono text-xs font-medium text-slate-300">{rating.toFixed(1)}</span>
      )}
    </div>
  );
}
