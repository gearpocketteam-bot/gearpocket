import { Review } from '@/types';

interface BadgeProps {
  badge: Review['badge'];
}

export default function Badge({ badge }: BadgeProps) {
  if (!badge) return null;

  const classes: Record<NonNullable<Review['badge']>, string> = {
    "Editor's Pick": 'badge badge-editor',
    'Best Value': 'badge badge-value',
    New: 'badge badge-new',
    'Top Rated': 'badge badge-top',
  };

  return <span className={classes[badge]}>{badge}</span>;
}
