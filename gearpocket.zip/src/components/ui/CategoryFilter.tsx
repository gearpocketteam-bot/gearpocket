'use client';

import { useState } from 'react';
import { Category } from '@/types';

const categories: (Category | 'ทั้งหมด')[] = [
  'ทั้งหมด',
  'หูฟัง',
  'Power Bank',
  'พัดลมพกพา',
  'ลำโพง',
  'เคสมือถือ',
  'สายชาร์จ',
];

const categoryEmoji: Record<string, string> = {
  ทั้งหมด: '🎯',
  หูฟัง: '🎧',
  'Power Bank': '🔋',
  พัดลมพกพา: '💨',
  ลำโพง: '🔊',
  เคสมือถือ: '📱',
  สายชาร์จ: '⚡',
};

interface CategoryFilterProps {
  onFilter?: (category: string) => void;
}

export default function CategoryFilter({ onFilter }: CategoryFilterProps) {
  const [active, setActive] = useState<string>('ทั้งหมด');

  const handleSelect = (cat: string) => {
    setActive(cat);
    onFilter?.(cat);
  };

  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
      {categories.map((cat) => (
        <button
          key={cat}
          onClick={() => handleSelect(cat)}
          className={`category-pill whitespace-nowrap ${
            active === cat ? 'category-pill-active' : 'category-pill-inactive'
          }`}
        >
          <span>{categoryEmoji[cat]}</span>
          {cat}
        </button>
      ))}
    </div>
  );
}
